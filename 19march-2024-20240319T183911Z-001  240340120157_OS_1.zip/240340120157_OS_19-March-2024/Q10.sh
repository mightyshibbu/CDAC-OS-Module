#!/bin/bash

echo "Number of arguments : $#"
echo "Script name : $0"
echo "2nd argument : $2"
echo "Argument passed : $@"
echo
if [ $# -gt 1 ]
then
echo "ERROR! More than one arguments!"
exit
fi 

if [ -b $@ ]; then
echo "File is of block type"
elif [ ! -e $@ ]; then
echo "File exist!"
elif [ -f $@ ]; then
echo "Ordinary file!"
elif [ -d $@ ]; then
echo "Directory!"
fi
