#!/bin/bash
modify() {
    echo "Enter new name for Roll No $rollno:"
    read new_name
    echo "Enter new marks for Subject 1:"
    read new_marks1
    echo "Enter new marks for Subject 2:"
    read new_marks2
    echo "Enter new marks for Subject 3:"
    read new_marks3

    sed -i "/^$rollno:/c\\$rollno:$new_name:$new_marks1:$new_marks2:$new_marks3" Q7.txt
    echo "Record modified successfully!"
}
echo "Enter Roll No to search:"
read rollno
if grep -q "^$rollno:" Q7.txt; then
    record=$(grep "^$rollno:" Q7.txt)
    IFS=':' read -r rollno name marks1 marks2 marks3 <<< "$record"
    modify
else
    echo "Roll No Not Found"
fi

