#!/bin/bash
delete() {
    sed -i "/^$rollno:/c\\" Q7.txt
    echo "Record Deleted successfully!"
}

echo "Enter Roll No to search:"
read rollno
if grep -q "^$rollno:" Q7.txt; then
    record=$(grep "^$rollno:" Q7.txt)
    IFS=':' read -r rollno name marks1 marks2 marks3 <<< "$record"
    delete    
else
    echo "Roll No Not Found"
fi
