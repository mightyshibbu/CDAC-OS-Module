#!/bin/bash
#From the above database substitute the delimiter of first 3 lines with “ : “
sed '1,3 s/|/ : /g' doc.txt
#From the above database substitute the delimiter with “ : ”
sed 's/|/ : /g' doc.txt
#Insert the string “ TechM Employees” in the first line
sed '1i\TechM Employees' doc.txt
#Store the lines pertaining to the directors, d.g.m and g.m into three separate files
sed -n '/director/p' doc.txt > directors.txt
sed -n '/d.g.m/p' doc.txt > dgm.txt
sed -n '/g.m/p' doc.txt > gm.txt
#Using address store first 4 lines into a file Empupdate
sed '1,4w Empupdate.txt' doc.txt
#Find the pattern “account” in the database and replaces that with “accounts”
sed 's/account/accounts/g' doc.txt
#Select those lines which do not have a pattern “g.m”.
sed '/g\.m/d' doc.txt
#Insert a blank line after every line in the database
sed 'G' doc.txt
