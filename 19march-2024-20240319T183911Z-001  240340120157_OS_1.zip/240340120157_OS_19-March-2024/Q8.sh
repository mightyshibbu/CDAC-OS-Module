#!/bin/bash
display() {
    echo "Roll No: $rollno"
    echo "Name: $name"
    echo "Subject 1 Marks: $marks1"
    echo "Subject 2 Marks: $marks2"
    echo "Subject 3 Marks: $marks3"
}

echo "Enter Roll No to search:"
read rollno
if grep -q "^$rollno:" Q7.txt; then
    record=$(grep "^$rollno:" Q7.txt)
    IFS=':' read -r rollno name marks1 marks2 marks3 <<< "$record"
    echo "Current Record:"
    display
else
    echo "Roll No Not Found"
fi
