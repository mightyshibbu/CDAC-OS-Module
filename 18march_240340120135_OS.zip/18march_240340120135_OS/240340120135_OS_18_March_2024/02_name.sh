#!/bin/bash

echo $fname
echo $mname
echo $lname

echo "Enter your first name: "
read fname

echo "Enter your middle name: "
read mname

echo "Enter your last name: "
read lname

echo "Good morning $fname $mname $lname !"




