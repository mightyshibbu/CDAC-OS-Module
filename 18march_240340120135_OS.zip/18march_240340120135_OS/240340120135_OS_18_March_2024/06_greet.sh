#!/bin/bash

time=$(date +%H)

echo "Namastey! "
if [ $time -ge 0 ] && [ $time -le 12 ]; then
	echo "It's MORNING! "
elif [ $time -ge 12 ] && [ $time -le 16 ]; then
	echo "It's AFTERNOON!"
elif [ $time -ge 16 ]; then
	echo "It's EVENING!"
else
	echo"It's NIGHT!"
fi
