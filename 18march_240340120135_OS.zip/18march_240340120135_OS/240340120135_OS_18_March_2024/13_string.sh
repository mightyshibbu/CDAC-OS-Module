#!/bin/bash
<<q1
myConcat(){
a=$1
b=$2
sum=$a$b;
echo "After concatanation: $sum"
}

read a
read b
myConcat $a $b
q1

<<q2
stringLength(){
a=$1
len=${#a}
echo "length : $len"
}
read a
stringLength $a 
q2
<<q3
stringCom(){
a=$1
b=$2
if [ "$1" == "$2" ];then
echo "Same!"
else
echo "Not Same!"
fi
}
read a
read b
stringCom $a $b
q3

#<<q4
palindrome(){
str="$1"
reversed_string=""
len=${#str}
for (( i=$len-1; i>=0; i-- ))
do
   reversed_string="$reversed_string${str:$i:1}"
done

if [ "$1" == "$reversed_string" ];then
echo "Palindrome!"
else
echo "Not Palindrome!"
fi
}
read -p "Enter a string: " a
palindrome $a 
#
<<q5
rev(){
str="$1"
reversed_string=""
len=${#str}
for (( i=$len-1; i>=0; i-- ))
do
   reversed_string="$reversed_string${str:$i:1}"
done
echo $reversed_string
}
name="Praful"
rev $name
q5
