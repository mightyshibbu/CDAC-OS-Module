#!/bin/bash


read -p "Give an Input" value

if grep -q "$value" Q11_2.txt 
then
	echo "For Exists " >> demo.txt
fi
