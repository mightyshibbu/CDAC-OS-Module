#!/bin/bash

echo "question 1:"
echo ""
## using nested loop for creating a pattern

for ((i+1; i<=5; i++)); do
	for ((j=1; j<=i; j++));do
		echo -n "*"
        	done
	## Newline
	echo ""
done
