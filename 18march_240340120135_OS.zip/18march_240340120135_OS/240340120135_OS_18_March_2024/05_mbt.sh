#!/bin/bash

echo "Enter your weight: "
read weight

if [ $weight -ge 30 ] && [ $weight -le 250 ]; then
	echo "Welcome to MBT health club"
else
	echo"Sorry!!!!Invalid weight"
fi
