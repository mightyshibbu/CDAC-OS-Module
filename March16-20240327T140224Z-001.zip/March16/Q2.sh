#!/bin/bash

echo "Enter first name"

read fname

echo "Enter mname"

read mname

echo "Enter lname"

read lname

echo "name is : $fname $mname $lname"
