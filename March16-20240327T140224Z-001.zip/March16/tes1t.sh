#!/bin/bash

a=10
b=5
c=$a+$b

echo "sum =c"$c
