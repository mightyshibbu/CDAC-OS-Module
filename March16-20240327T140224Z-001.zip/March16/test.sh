#!/bin/bash


#Variable shjhjhj

<<Shan
CDAC DAC 
hgutiku
kujiuy]
Shan

echo "Hello Bro"
